//Lecture: Hoisting
/*

function calculateAge (year){
    console.log(2017-year);
};

calculateAge(1990);


calculateAge(1965);



var retirement = function(year){
    console.log(65 - (2016 - year));
};

retirement(1990);




//varriables 


console.log(age);
var age = 23;
console.log(age);


function foo() {
    var age = 65;
    console.log(age);
};

foo();
console.log(age);


//scoping

scoping ansers the question "where can we access a certain variable?"
- each new function creates a scope: the space/environment in which the variable it defines are accessable. 
lexical scoping : a function that is lexically within another unction gets access to scope of the outer function(parent)*/






/*

var a = 'Hello!';
first();

function first () {
    var b = 'Hi!'
} 

*/



///////////////////////////////////////
// Lecture: Scoping


// First scoping example

/*
var a = 'Hello!';
first();

function first() {
    var b = 'Hi!';
    second();

    function second() {
        var c = 'Hey!';
        console.log(a + b + c);
    }
}
*/



// Example to show the differece between execution stack and scope chain

/*
var a = 'Hello!';
first();

function first() {
    var b = 'Hi!';
    second();

    function second() {
        var c = 'Hey!';
        third()
    }
}

function third() {
    var d = 'John';
    console.log(a + b + c + d);
}
*/

/*
///////////////////////////////////////
// Lecture: The this keyword
 

//console.log(this);
calculateAge(1922);

function calculateAge(year){
    console.log(2017 - year)
    console.log(this);
};


*/
var john = {
    name: 'John',
    yearOfBirth: 1990,
    calculateAge: function(){
        console.log(this);
        console.log(2017 - this.yearOfBirth);
        /*function innerFunction(){
            console.log(this);
        }
        innerFunction();
    */ 
    }
}


john.calculateAge();



var Allie = {
    name: 'Allison',
    yearOfBirth: 1992,
};

Allie.calculateAge = john.calculateAge;
Allie.calculateAge();














