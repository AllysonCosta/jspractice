/*
// Lecture: Variables
var name = 'John';
console.log(name);

var lastName = 'Smith';
console.log(lastName)  ;    

var age = 26;

console.log(age);

var fullAge = 'true';
console.log(fullAge);
*/

// Lectures: Variables 2
/*
var name = "John";
var lastName = "Smith";
var age = 26;

var job, isMarried;

console.log(name + age);
console.log('His name is ' + name + ' and he is' + age + ' years old.');

job = 'teacher';
isMarried = true;

console.log(name + ' is a '+ age + ' year old' + job + '. Is he Married? '+ isMarried + '.');

age = 'thirty six';
job = 'driver';

console.log(name + ' is a '+ age + ' year old ' + job + '. Is he Married? '+ isMarried + '.');

//var lastName = prompt('What is the last name?');
//console.log(lastName);

//alert(name + ' is a '+ age + ' year old ' + job + '. Is he Married? '+ isMarried + '.');
*/



//Lecture: operators
/*
var now = 2017;
var birthYear = now - 26;

birthyear = now - 26 * 2;
 

console.log(birthYear);

var ageJohn = 30;
var ageMark = 30;


ageJohn = AgeMark = (3+5) * 4 - 6;

ageJohn++;
ageMark *= 2 ;

console.log(ageJohn);
console.log(ageMark);

*/

//Lecture: if/else statements

/*
var name = "John"
var age = 26;
var isMarried = 'yes';


if (isMarried === 'yes'){
   
    console.log(name + ' is married:');
} else {
    console.log (name + ' will hopefully marry soon!');
};

isMarried = false ;

if(isMarried){
    console.log('YES!');
} else {
    console.log('NO!');
};

if (23 === "23"){
    console.log('print');
};



*/

//Lecture: bolean logic and switch
/*
var age = 25;

if (age < 20){
    console.log('John is a teenager!')
} else if (age >= 20 && age <= 30) {
    console.log('John is a young man')
} else {
    console.log('John is a man.')
};
*/

/*
var job = 'teacher';

job = prompt('What does John do?');
switch (job) {
    case 'teacher':
        console.log('John teaches kids.');
        break;
    case 'driver':
        console.log('John drives a cab in Lisbon.');
        break;
    case 'cop':
        console.log('John helps to fight crime!');
        break; 
    default: 
        console.log('John does something else.');
};

9?
*/
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//Coding Challenge #1

// obtains parameters. 

var johnAge = 29;
var markAge = 32;
var jamesAge = 19;

var johnHeight = 72;
var markHeight = 68;
var jamesHeight = 75;

//test for tie game = Success!

var johnAge = 20;
var markAge = 20;
var jamesAge = 20;

var johnHeight = 72;
var markHeight = 72;
var jamesHeight = 72;
*/
/*
//calculates game scores ( (age*5) + height)
var johnScore = johnHeight + (johnAge * 5);
var markScore = markHeight + (markAge * 5);
var jamesScore = jamesHeight + (jamesAge * 5);



//determins winner - logs to console.

if (johnScore > markScore && johnScore > jamesScore) {
    console.log('John is the winner!');
} else if (markScore > johnScore && markScore > jamesScore ) {
    console.log('Mark is the winner!');
} else if (jamesScore > johnScore && jamesScore > markScore ) {
    console.log ('James is the winner!');
} else {
    console.log('Wow! Its a tie game!');
};
  
//end of code challenge
//////////////////////////////////////////////////////////


//Lecture: Functions

function calculateAge (yearofBirth) {
    var age = 2017 - yearofBirth;
    return age;  
}

var ageJohn = calculateAge (1990);
var ageMike = calculateAge (1969);
var ageMary = calculateAge (1948);

//console.log(ageJohn + ' '+ ageMike + ' '+ ageMary);

function yearsUntilRetirement(name, year) {
  var age = calculateAge(year);
  var retirement = 65 - age;
    
    if ( retirement >= 0 ){
       console.log(name + ' retires in ' + retirement + ' years.'); 
    } else {
        console.log(name + ' has already retired!');
    }
    
}

yearsUntilRetirement('John' , 1990);
yearsUntilRetirement('Mike' , 1969);
yearsUntilRetirement('Mary', 1938);
*/
/*
function someFun(par) {
    //code
}


var somefun = Function(par) {
    //code 
}
*/


// Lecture: Arrays
/*

var names = ['Allyson', 'Allison', 'Alison' ];
var years = new Array (1990, 1991, 1992);

console.log(names); 
console.log(names[1]);

names[0] = 'Ally';
console.log(names);

var john = ['John', 'Smith', 1990, 'stripper', false];

john.push('red');

john.pop();
john.unshift('Mr.');
john.shift();

console.log(john);


let career = john[3];
console.log(career);


alert(john.indexOf('Smith'));

if (john.indexOf('teacher') === -1){
    console.log('John is not a teacher');
};

*/

//Lectures: Objects

//1st way
/*
var Ally = {
    firstName: 'Allyson',
    lastName:'Costa',
    yearofBirth: 1991,
    job: 'Teachnical account Manager',
    isMarried: false
}
console.log(Ally);
console.log(Ally.lastName);
console.log(Ally['lastName']);

var career = 'job';
console.log(Ally[career]);
Ally.firstName= 'Ally';

console.log(Ally);

//2nd way

var allie = new Object();

allie.firstName = 'Allie';
allie.lastName = 'Yancy';
allie.yearofBirth = 1992;
allie.job = 'Full Stack Developer';
allie.isMarried = false;

console.log(allie);
*/
/*
//version 1.0
var Ally = {
    firstName: 'Allyson',
    lastName: 'Costa',
    yearofBirth: 1991,
    job: 'Teachnical account Manager',
    isMarried: false,
    family: ['Tony' , 'Mary' , 'Ellie' , 'Norah' , 'Megan'],
    calculateAge: function(){
        return 2017 - this.yearofBirth;
    }
    
};

var Ally = {
    firstName: 'Allyson',
    lastName: 'Costa',
    yearofBirth: 1991,
    job: 'Teachnical account Manager',
    isMarried: false,
    family: ['Tony' , 'Mary' , 'Ellie' , 'Norah' , 'Megan'],
    calculateAge: function(){
        this.age = 2017 - this.yearofBirth;
        //return 2017 - this.yearofBirth;
    }
    
};

Ally.calculateAge();
console.log(Ally);


*/

//Lectures: Loops
/*
for (var i = 0; x < 10; x++) {
    console.log(x);
}
*/
//for loops
/*
var names = ['Tony' , 'Mary' , 'Ellie' , 'Norah' , 'Megan'];

for (var i = -5; i < names.length ; i++) {
    console.log(names[i]);
};


/*
for (var i = names.length - 1 ; i >= 0 ; i--) {
    console.log(names[i]);
}

*/


//while loops

/*

var names = ['Tony' , 'Mary' , 'Ellie' , 'Norah' , 'Megan'];

var i = 0;

while (i < names.length ){
    console.log(names[i]);
    i++;
}


for ( var i = 0; i <= 15 ; i++) {
    console.log(i);
    if (i === 15) {
        break;
    }    
    
}

for ( var i = 0; i <= 15 ; i++) {
   
    if (i === 15) {
        continue;
    }    
    console.log(i);
}

*/







//Coding Challenge # 2


var birthYears = [1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999];

var emptyArray =[];

//for (var i = 0; i => birthYears.length; i++) 
//{
  //var  arrayPositions = i;
    //emptyArray.unshift(birthYears[i]);
//};


console.log(emptyArray);

console.log(birthYears);

















































































































































































































































































































































































