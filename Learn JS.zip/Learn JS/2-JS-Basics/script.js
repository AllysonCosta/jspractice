
//Coding Challenge # 2


var birthYears = [1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004];

var emptyArray = [];


var counter = 0;
while (counter < birthYears.length) {
var  arrayPositions = counter;
    emptyArray.unshift(2017 - birthYears[arrayPositions]);
    counter++;
};

//console.log(emptyArray);

for (var i = 0; i < emptyArray.length; i++ ) {
    if (emptyArray[i] < 18) {
        console.log('Age: ' + emptyArray[i] + '. They are under age!');
        
    } else {
        console.log('Age: ' + emptyArray[i] +'. They are of age!');
    };
    
    
}; 
     
function printFullAge(birthYears) {
   var age = 2017 - birthYears;
    if (age >= 18) {
        console.log('Age: ' + age + '. They are of age!');
        console.log(true);
    } else {
        console.log('Age: ' + age + '. They are NOT of age!');
        console.log(false);
    };
  };  
    
var agePromptA = prompt('What year was the first person born? ');
var agePromptB = prompt('What year was the second person born?');    
var full_1 = printFullAge(agePromptA);
var full_2 = printFullAge(agePromptB);
//var full_2 = printFullAge(agePrompt;

   
    
    
    /*var emptyArray = [];
    var counter = 0;
    while (counter < birthYears.length) {
    var  arrayPositions = counter;
    emptyArray.unshift(2017 - birthYears[arrayPositions]);
    counter++;
    };
    console.log(emptyArray); 
    if (emptyArray < 18 ){
        console.log(false);
    }
    else {
        console.log(true);
    };


var full_1 = printFullAge();
var full_2 = printFullAge();

console.log(full_1);
console.log(full_2);




*/









































































































































































































































































































































































